//===============================================================================
// Microsoft patterns & practices Enterprise Library
// Application Block Software Factory
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Configuration.Design;
using AAD.ProvidersLibrary.Configuration.Design.Properties;

namespace AAD.ProvidersLibrary.Configuration.Design
{
	sealed partial class CommandRegistrar : Microsoft.Practices.EnterpriseLibrary.Configuration.Design.CommandRegistrar
	{
		public CommandRegistrar(IServiceProvider serviceProvider)
			: base(serviceProvider)
		{
		}

		public override void Register()
		{
		
			AddRollingFlatFileTraceListenerNodeCommand();
			AddDefaultCommands(typeof(RollingFlatFileTraceListenerNode));
			// TODO: Add other non-default commands to the RollingFlatFileTraceListenerNode Design-Time Node.
		}
	}
}
