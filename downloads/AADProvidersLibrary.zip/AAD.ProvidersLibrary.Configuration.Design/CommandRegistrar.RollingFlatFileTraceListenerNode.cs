﻿using System;
using AAD.ProvidersLibrary.Configuration.Design.Properties;

namespace AAD.ProvidersLibrary.Configuration.Design
{
	sealed partial class CommandRegistrar
	{
		private void AddRollingFlatFileTraceListenerNodeCommand()
		{
			AddMultipleChildNodeCommand(
				Resources.RollingFlatFileTraceListenerNodeUICommandText,
				Resources.RollingFlatFileTraceListenerNodeUICommandLongText,
				typeof(RollingFlatFileTraceListenerNode),
				typeof(Microsoft.Practices.EnterpriseLibrary.Logging.Configuration.Design.TraceListeners.TraceListenerCollectionNode));

		}
	}
}


