﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Drawing.Design;
using Microsoft.Practices.EnterpriseLibrary.Configuration.Design;
using Microsoft.Practices.EnterpriseLibrary.Configuration.Design.Validation;
using AAD.ProvidersLibrary.Configuration.Design.Properties;
using Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners;
using Microsoft.Practices.EnterpriseLibrary.Logging.Configuration.Design.Formatters;

namespace AAD.ProvidersLibrary.Configuration.Design
{
	/// <summary>
	/// Represents a <see cref="AAD.ProvidersLibrary.Configuration.RollingFlatFileTraceListenerData"/> configuration element. 
	/// </summary>
	public class RollingFlatFileTraceListenerNode : Microsoft.Practices.EnterpriseLibrary.Logging.Configuration.Design.TraceListeners.TraceListenerNode
	{
		private FormatterNode formatterNode;
		private string formatterName;

		/// <summary>
		/// Initialize a new instance of the <see cref="RollingFlatFileTraceListenerNode"/> class.
		/// </summary>
		public RollingFlatFileTraceListenerNode()
			: this(new RollingFlatFileTraceListenerData(
							Resources.RollingFlatFileTraceListenerNodeUICommandText,
							"rollingwithpurge.log",
							"----------------------------------------",
							"----------------------------------------",
							0,
							"yyyy-MM-dd HH.mm.ss",
							RollFileExistsBehavior.Overwrite,
							RollInterval.None,
							System.Diagnostics.TraceOptions.None,
							null,
							0
			))
		{
		}

		/// <summary>
		/// Initialize a new instance of the <see cref="RollingFlatFileTraceListenerNode"/> class with a <see cref="AAD.ProvidersLibrary.Configuration.RollingFlatFileTraceListenerData"/> instance.
		/// </summary>
		/// <param name="data">A <see cref="AAD.ProvidersLibrary.Configuration.RollingFlatFileTraceListenerData"/> instance</param>
		public RollingFlatFileTraceListenerNode(AAD.ProvidersLibrary.Configuration.RollingFlatFileTraceListenerData data)
		{
			if (null == data) throw new ArgumentNullException("data");

			Rename(data.Name);
			this.filesToKeep = data.FilesToKeep;
			this.fileName = data.FileName;
			this.rollSizeKB = data.RollSizeKB;
			this.timeStampPattern = data.TimeStampPattern;
			this.rollFileExistsBehavior = data.RollFileExistsBehavior;
			this.rollInterval = data.RollInterval;
			this.formatterName = data.Formatter;
			this.header = data.Header;
			this.footer = data.Footer;
			this.TraceOutputOptions = data.TraceOutputOptions;
		}

		/// <summary>
		/// Gets the <see cref="AAD.ProvidersLibrary.Configuration.RollingFlatFileTraceListenerData"/> this node represents.
		/// </summary>
		/// <value>
		/// The <see cref="AAD.ProvidersLibrary.Configuration.RollingFlatFileTraceListenerData"/> this node represents.
		/// </value>
		[Browsable(false)]
		public override Microsoft.Practices.EnterpriseLibrary.Logging.Configuration.TraceListenerData TraceListenerData
		{
			get
			{
				RollingFlatFileTraceListenerData data = new RollingFlatFileTraceListenerData(this.Name,
																fileName,
																header,
																footer,
																rollSizeKB,
																timeStampPattern,
																rollFileExistsBehavior,
																rollInterval,
																this.TraceOutputOptions,
																formatterName,
																filesToKeep);
				return data;
			}
		}

		/// <summary>
		/// Releases the unmanaged resources used by the <see cref="RollingFlatFileTraceListenerNode"/> and optionally releases the managed resources.
		/// </summary>
		/// <param name="disposing">
		/// <see langword="true"/> to release both managed and unmanaged resources; <see langword="false"/> to release only unmanaged resources.
		/// </param>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
			}
			base.Dispose(disposing);
		}

		private System.Int32 filesToKeep;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("FilesToKeepDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public System.Int32 FilesToKeep
		{
			get { return this.filesToKeep; }
			set { this.filesToKeep = value; }
		}

		private System.String fileName;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("FileNameDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public System.String FileName
		{
			get { return this.fileName; }
			set { this.fileName = value; }
		}

		private System.Int32 rollSizeKB;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("RollSizeKBDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public System.Int32 RollSizeKB
		{
			get { return this.rollSizeKB; }
			set { this.rollSizeKB = value; }
		}

		private System.String timeStampPattern;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("TimeStampPatternDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public System.String TimeStampPattern
		{
			get { return this.timeStampPattern; }
			set { this.timeStampPattern = value; }
		}

		private Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollFileExistsBehavior rollFileExistsBehavior;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("RollFileExistsBehaviorDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollFileExistsBehavior RollFileExistsBehavior
		{
			get { return this.rollFileExistsBehavior; }
			set { this.rollFileExistsBehavior = value; }
		}

		private Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollInterval rollInterval;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("RollIntervalDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollInterval RollInterval
		{
			get { return this.rollInterval; }
			set { this.rollInterval = value; }
		}

		private System.String header;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("HeaderDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public System.String Header
		{
			get { return this.header; }
			set { this.header = value; }
		}

		private System.String footer;
		/// <summary>
		/// 
		/// </summary>
		/// <value>
		/// 
		/// </value>
		[SRDescription("FooterDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public System.String Footer
		{
			get { return this.footer; }
			set { this.footer = value; }
		}

		/// <summary>
		/// Gets or sets the formatter for the file.
		/// </summary>
		/// <value>
		/// The formatter for the file.
		/// </value>
		[Editor(typeof(ReferenceEditor), typeof(UITypeEditor))]
		[ReferenceType(typeof(FormatterNode))]
		[SRDescription("FormatDescription", typeof(Resources))]
		[SRCategory("CategoryGeneral", typeof(Resources))]
		public FormatterNode Formatter
		{
			get { return formatterNode; }
			set
			{
				formatterNode = LinkNodeHelper.CreateReference<FormatterNode>(formatterNode,
					value,
					OnFormatterNodeRemoved,
					OnFormatterNodeRenamed);

				formatterName = formatterNode == null ? string.Empty : formatterNode.Name;
			}
		}

		/// <summary>
		/// Sets the formatter to use for this listener.
		/// </summary>
		/// <param name="formatterNodeReference">
		/// A <see cref="FormatterNode"/> reference or <see langword="null"/> if no formatter is defined.
		/// </param>
		protected override void SetFormatterReference(ConfigurationNode formatterNodeReference)
		{
			if (formatterName == formatterNodeReference.Name) Formatter = (FormatterNode)formatterNodeReference;
		}

		private void OnFormatterNodeRemoved(object sender, ConfigurationNodeChangedEventArgs e)
		{
			formatterNode = null;
		}

		private void OnFormatterNodeRenamed(object sender, ConfigurationNodeChangedEventArgs e)
		{
			formatterName = e.Node.Name;
		}
	}
}
