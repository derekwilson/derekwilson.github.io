//===============================================================================
// Microsoft patterns & practices Enterprise Library
// Application Block Software Factory
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY
// OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT
// LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
// FITNESS FOR A PARTICULAR PURPOSE.
//===============================================================================

using System.Reflection;
using System.Security.Permissions;
using Microsoft.Practices.EnterpriseLibrary.Configuration.Design;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using AAD.ProvidersLibrary.Configuration.Design;

// TODO: Add dependent configuration design managers for $ProjectName$.Configuration.Design if they are needed
//[assembly: Microsoft.Practices.EnterpriseLibrary.Configuration.Design.ConfigurationDesignManager(typeof(AAD.ProvidersLibrary.Configuration.Design.ConfigurationDesignManager),typeof(DependentConfigurationDesignManager1))]
//[assembly: Microsoft.Practices.EnterpriseLibrary.Configuration.Design.ConfigurationDesignManager(typeof(AAD.ProvidersLibrary.Configuration.Design.ConfigurationDesignManager),typeof(DependentConfigurationDesignManager2))]
[assembly: Microsoft.Practices.EnterpriseLibrary.Configuration.Design.ConfigurationDesignManager(typeof(AAD.ProvidersLibrary.Configuration.Design.ConfigurationDesignManager))]

[assembly: ReflectionPermission(SecurityAction.RequestMinimum, MemberAccess = true)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum)]

[assembly: ComVisible(false)]

[assembly: AssemblyTitle("AAD.ProvidersLibrary Provider Library Design-Time")]
[assembly: AssemblyDescription("AAD.ProvidersLibrary Provider Library")]
[assembly: AssemblyCompany("Andrew and Derek")]
[assembly: AssemblyVersion("2.0.0.0")]
