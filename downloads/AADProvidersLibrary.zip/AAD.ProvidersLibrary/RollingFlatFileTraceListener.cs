﻿using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Collections.Generic;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.Common.Instrumentation;
using AAD.ProvidersLibrary.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging.Formatters;
using Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners;
using System.IO;
using System.Reflection;
using System.Collections;

namespace AAD.ProvidersLibrary
{
    /// <summary>
    /// Extended RollingFlatFileTRaceListener
    /// </summary>
	public class RollingFlatFileTraceListener : Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners.RollingFlatFileTraceListener
    {
#if DEBUG
		static bool _bFirstRun = true;
#endif
		private int _nFilesToKeep;
		string _timestampFormat;

		/// <summary>
		/// Initializes a new instance of <see cref="RollingFlatFileTraceListener"/>
		/// </summary>
		/// <param name="fileName">The filename where the entries will be logged.</param>
		/// <param name="header">The header to add before logging an entry.</param>
		/// <param name="footer">The footer to add after logging an entry.</param>
		/// <param name="formatter">The formatter.</param>
		/// <param name="rollSizeKB">The maxium file size (KB) before rolling.</param>
		/// <param name="timeStampPattern">The date format that will be appended to the new roll file.</param>
		/// <param name="rollFileExistsBehavior">Expected behavior that will be used when the rool file has to be</param>
		/// <param name="rollInterval">The time interval that makes the file rolles.</param>
		public RollingFlatFileTraceListener(
			string fileName,
			string header,
			string footer,
			ILogFormatter formatter,
			int rollSizeKB,
			string timeStampPattern,
			RollFileExistsBehavior rollFileExistsBehavior,
			RollInterval rollInterval,
			int filesToKeep
			)
			: base(
				fileName,
				header,
				footer,
				formatter,
				rollSizeKB,
				timeStampPattern,
				rollFileExistsBehavior,
				rollInterval
			)
        {
			this._nFilesToKeep = filesToKeep;
			this._timestampFormat = timeStampPattern;		// DOH - its private in the base class
        }

        // TODO: Decide whether a constructor with discrete arguments is necessary for the RollingFlatFileTraceListener.
        //public RollingFlatFileTraceListener(object param1, object param2)
        //{
        //    this.var1 = param1;
        //    this.var2 = param2;
        //}

        /// <summary>
        /// Writes trace information, a data object and event information to the file, performing a roll if necessary.
        /// </summary>
        /// <param name="eventCache">A <see cref="TraceEventCache"/> object that contains the current process ID,threadID, and stack trace information.</param>
        /// <param name="source">A name used to identify the output, typically the name of the applicationthatgenerated the trace event.</param>
        /// <param name="eventType">One of the <see cref="TraceEventType"/> values specifying the type of event that has caused the trace.</param>
        /// <param name="id">A numeric identifier for the event.</param>
        /// <param name="data">The trace data to emit.</param>
        public override void TraceData(TraceEventCache eventCache, string source, TraceEventType eventType, int id, object data)
        {
#if DEBUG
			if (_bFirstRun)
			{
				Assembly me = System.Reflection.Assembly.GetExecutingAssembly();
				AssemblyName name = me.GetName();
				Debug.Print(string.Format("Enter TraceData v{0}", name.Version));
			}
#endif
			// output data rolling if necessary
            base.TraceData(eventCache, source, eventType, id, data);
			// purge excess
			if (_nFilesToKeep > 0)
				PurgeExcessFIles();

#if DEBUG
			if (_bFirstRun)
			{
				Debug.Print("Exit TraceData v{0}");
				_bFirstRun = false;
			}
#endif
		}

        private void PurgeExcessFIles()
        {
			string actualFileName = ((FileStream)((StreamWriter)this.Writer).BaseStream).Name;
			string directory = Path.GetDirectoryName(actualFileName);
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(actualFileName);
			string extension = Path.GetExtension(actualFileName);
			string pattern = fileNameWithoutExtension + "*" + extension;

			DirectoryInfo dir = new DirectoryInfo(directory);
			if (!dir.Exists)
			{
				return;
			}

			FileInfo[] files = dir.GetFiles(pattern);
			int filesToPurge = files.Length - _nFilesToKeep;
			if (filesToPurge <= 0)
			{
				return;
			}

#if DEBUG
			Debug.Print(string.Format("Looking for {0} files to purge", filesToPurge));
#endif

			// we must sort the folder rather than relying on the files being written in the correct order
			IComparer fileComparer = new CompareFileByFilenameTimeStamp(fileNameWithoutExtension, _timestampFormat);
			Array.Sort(files, fileComparer);

			foreach (FileInfo file in files)
			{
				if (CompareFileByFilenameTimeStamp.ConvertTimestampToTime(file.Name, fileNameWithoutExtension, _timestampFormat) < DateTime.MaxValue)
				{
#if DEBUG
					Debug.Print(string.Format("Purging {0}", file.FullName));
#endif

					// only delete files that match the pattern
					file.Delete();
					filesToPurge--;
					if (filesToPurge < 1)
						break;
				}
			}
		}
	}
}
