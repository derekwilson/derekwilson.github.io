using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;
using System.Globalization;
using System.Diagnostics;

namespace AAD.ProvidersLibrary
{
	/// <summary>
	/// Class to sort the files into the correct order acording to their timestamp
	/// </summary>
	public class CompareFileByFilenameTimeStamp : IComparer
	{
		string _baseFilename;
		string _timestampFormat;

		public CompareFileByFilenameTimeStamp(string aBaseFilename, string aFormat)
		{
			_baseFilename = aBaseFilename;
			_timestampFormat = aFormat;
		}

		int IComparer.Compare(Object a, Object b)
		{
			FileInfo fa = a as FileInfo;
			FileInfo fb = b as FileInfo;

			if (fa == null && fb == null)
				return 0;
			if (fa == null)
				return -1;
			if (fb == null)
				return 1;

			DateTime da = ConvertTimestampToTime(fa.Name, _baseFilename, _timestampFormat);
			DateTime db = ConvertTimestampToTime(fb.Name, _baseFilename, _timestampFormat);

			return DateTime.Compare(da,db);
		}

		public static DateTime ConvertTimestampToTime(string aFilename, string aBaseFilename, string aTimestampFormat)
		{
			try
			{
				// the timestamp is after the base filename
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(aFilename);

				string timestamp = fileNameWithoutExtension;
				if (timestamp.Length > aBaseFilename.Length + 1)
					timestamp = timestamp.Substring(aBaseFilename.Length + 1);

				DateTimeFormatInfo DTFI = new CultureInfo("en-US", false).DateTimeFormat;
				return DateTime.ParseExact(timestamp, aTimestampFormat, DTFI);
			}
			catch
			{
				// if we do not recognise the time then sort to the end of the list
				return DateTime.MaxValue;
			}
		}		
	}
}
