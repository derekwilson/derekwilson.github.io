﻿using System;
using System.Diagnostics;
using System.ComponentModel;
using System.Configuration;
using Microsoft.Practices.ObjectBuilder2;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration.ObjectBuilder;
using Microsoft.Practices.EnterpriseLibrary.Logging.Configuration;
using AAD.ProvidersLibrary;
using Microsoft.Practices.EnterpriseLibrary.Logging.Formatters;
using Microsoft.Practices.EnterpriseLibrary.Logging.TraceListeners;

namespace AAD.ProvidersLibrary.Configuration
{
    /// <summary>
    /// Represents the configuration data for a <see cref="RollingFlatFileTraceListener"/>.
    /// </summary>	
    [Assembler(typeof(RollingFlatFileTraceListenerAssembler))]
    public class RollingFlatFileTraceListenerData : Microsoft.Practices.EnterpriseLibrary.Logging.Configuration.RollingFlatFileTraceListenerData
    {
		/// <summary>
		/// Initializes a new instance of the <see cref="TraceListenerData"/> class.
		/// </summary>
		public RollingFlatFileTraceListenerData()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="RollingFlatFileTraceListenerData"/> class.
		/// </summary>
		/// <param name="name">The name for the configuration object.</param>
		/// <param name="traceOutputOptions">The trace options.</param>
		/// <param name="fileName"></param>
		/// <param name="footer"></param>
		/// <param name="header"></param>
		/// <param name="rollSizeKB"></param>
		/// <param name="timeStampPattern"></param>
		/// <param name="rollFileExistsBehavior"></param>
		/// <param name="rollInterval"></param>
		/// <param name="formatter"></param>
		public RollingFlatFileTraceListenerData(string name,
			string fileName,
			string header,
			string footer,
			int rollSizeKB,
			string timeStampPattern,
			RollFileExistsBehavior rollFileExistsBehavior,
			RollInterval rollInterval,
			TraceOptions traceOutputOptions,
			string formatter,
			int filesToKeep)
			: base(
			name,
			fileName,
			header,
			footer,
			rollSizeKB,
			timeStampPattern,
			rollFileExistsBehavior,
			rollInterval,
			traceOutputOptions,
			formatter
			)
		{
			this.FilesToKeep = filesToKeep;

			// we must do this as we have inherited from the RollingTraceListener and it will have set its type in the base constructor
			// setting this means that the Config Tool UI will write the correct Type attrib in the config file
			this.Type = typeof(AAD.ProvidersLibrary.RollingFlatFileTraceListener);
		}

        private const string FilesToKeepPropertyName = "filesToKeep";
        [ConfigurationProperty(FilesToKeepPropertyName)]
        public int FilesToKeep
        {
            get { return (int)this[FilesToKeepPropertyName]; }
            set { this[FilesToKeepPropertyName] = value; }
        }
    }

    /// <summary>
    /// This type supports the Enterprise Library infrastructure and is not intended to be used directly from your code.
    /// Represents the process to build a <see cref="RollingFlatFileTraceListener"/> described by a <see cref="RollingFlatFileTraceListenerData"/> configuration object.
    /// </summary>
    /// <remarks>This type is linked to the <see cref="RollingFlatFileTraceListenerData"/> type and it is used by the  Custom Factory
    /// to build the specific <see cref="TraceListener"/> object represented by the configuration object.
    /// </remarks>
	public class RollingFlatFileTraceListenerAssembler : Microsoft.Practices.EnterpriseLibrary.Logging.Configuration.RollingTraceListenerAssembler
    {
        /// <summary>
        /// Builds a <see cref="RollingFlatFileTraceListener"/> based on an instance of <see cref="TraceListenerData"/>.
        /// </summary>
        /// <param name="context">The <see cref="IBuilderContext"/> that represents the current building process.</param>
        /// <param name="objectConfiguration">The configuration object that describes the object to build. Must be an instance of <see cref="TraceListenerData"/>.</param>
        /// <param name="configurationSource">The source for configuration objects.</param>
        /// <param name="reflectionCache">The cache to use retrieving reflection information.</param>
        /// <returns>A fully initialized instance of <see cref="TraceListener"/>.</returns>
        public override TraceListener Assemble(IBuilderContext context, TraceListenerData objectConfiguration, IConfigurationSource configurationSource, ConfigurationReflectionCache reflectionCache)
        {

            RollingFlatFileTraceListenerData castObjectConfiguration
                = (RollingFlatFileTraceListenerData)objectConfiguration;

			ILogFormatter formatter = GetFormatter(context, castObjectConfiguration.Formatter, configurationSource, reflectionCache);

			RollingFlatFileTraceListener createdObject
				= new RollingFlatFileTraceListener(
					castObjectConfiguration.FileName,
					castObjectConfiguration.Header,
					castObjectConfiguration.Footer,
					formatter,
					castObjectConfiguration.RollSizeKB,
					castObjectConfiguration.TimeStampPattern,
					castObjectConfiguration.RollFileExistsBehavior,
					castObjectConfiguration.RollInterval,
					castObjectConfiguration.FilesToKeep
					);

//            RollingFlatFileTraceListener createdObject
//                = new RollingFlatFileTraceListener(castObjectConfiguration);

            return createdObject;
        }
    }
}
